namespace ConfigHomework.Configuration;

public class YamlConfigurationSource : IConfigurationSource
{
    public string Path { get; set; } = string.Empty;
    public bool Optional { get; set; }

    public IConfigurationProvider Build(IConfigurationBuilder builder)
    {
        return new YamlConfigurationProvider(Path, Optional);
    }
}
