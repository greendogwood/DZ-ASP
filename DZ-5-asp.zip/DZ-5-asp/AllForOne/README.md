# ASP.NET Core Configuration Homework

Проект создан в JetBrains Rider (net10.0).

## Задание 1. Получение значений из конфигурации

- `appsettings.json` содержит секцию `Application` с `Name`, `Version`, `MaxItems`
- `appsettings.Development.json` переопределяет минимум два значения
- Эндпоинт `GET /api/settings` получает значения двумя способами:
  - по ключу (`configuration["Application:Name"]`)
  - через секцию (`configuration.GetSection("Application")`)

## Задание 2. Конфигурирование объектов с использованием IOptions

- Класс `ApplicationOptions`
- Регистрация через `AddOptions().Bind().Validate().ValidateOnStart()`
- `ApplicationInfoService` получает настройки через `IOptionsMonitor<ApplicationOptions>`
- Эндпоинт `GET /api/application-info`
- Валидация при старте

### Разница между интерфейсами Options

| Интерфейс              | Lifetime   | Перечитывает конфигурацию | OnChange | Когда использовать                  |
|------------------------|------------|---------------------------|----------|-------------------------------------|
| `IOptions<T>`          | Singleton  | Нет                       | Нет      | Статические настройки               |
| `IOptionsSnapshot<T>`  | Scoped     | Да (на каждый scope)      | Нет      | Настройки на запрос                 |
| `IOptionsMonitor<T>`   | Singleton  | Да                        | Да       | Долгоживущие сервисы + hot reload   |

## Задание 3. Собственный провайдер конфигурации для YML

- Файл `appsettings.yml`
- `YamlConfigurationProvider` + `YamlConfigurationSource`
- Метод расширения `AddYamlFile()`
- Ключи в формате `Application:Name`, `Features:NewDashboard`
- Обработка отсутствия файла и ошибок парсинга

## Как открыть в Rider

1. Распакуй архив
2. Открой `ConfigHomework.sln` в Rider
3. Нажми Run

## Эндпоинты

- `GET /api/settings`
- `GET /api/application-info`
- `GET /api/options-info`
