using Microsoft.Extensions.Options;

namespace ConfigHomework;

public class ApplicationInfoService
{
    private readonly IOptionsMonitor<ApplicationOptions> _options;

    public ApplicationInfoService(IOptionsMonitor<ApplicationOptions> options)
    {
        _options = options;
    }

    public ApplicationInfo GetApplicationInfo()
    {
        var current = _options.CurrentValue;
        return new ApplicationInfo
        {
            Name = current.Name,
            Version = current.Version,
            MaxItems = current.MaxItems,
            Source = "IOptionsMonitor (supports reload and notifications)"
        };
    }
}

public class ApplicationInfo
{
    public string Name { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public int MaxItems { get; set; }
    public string Source { get; set; } = string.Empty;
}
