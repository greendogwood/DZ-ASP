using ConfigHomework.Configuration;

namespace Microsoft.Extensions.Configuration;

public static class YamlConfigurationExtensions
{
    public static IConfigurationBuilder AddYamlFile(
        this IConfigurationBuilder builder,
        string path,
        bool optional = false)
    {
        ArgumentNullException.ThrowIfNull(builder);
        ArgumentException.ThrowIfNullOrEmpty(path);

        return builder.Add(new YamlConfigurationSource
        {
            Path = path,
            Optional = optional
        });
    }
}
