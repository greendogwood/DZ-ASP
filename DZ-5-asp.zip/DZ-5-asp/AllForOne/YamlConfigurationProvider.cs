using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace ConfigHomework.Configuration;

public class YamlConfigurationProvider : ConfigurationProvider
{
    private readonly string _path;
    private readonly bool _optional;

    public YamlConfigurationProvider(string path, bool optional)
    {
        _path = path;
        _optional = optional;
    }

    public override void Load()
    {
        if (!File.Exists(_path))
        {
            if (_optional)
            {
                Data = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
                return;
            }
            throw new FileNotFoundException($"Required YAML configuration file not found: {_path}");
        }

        try
        {
            var yamlContent = File.ReadAllText(_path);
            var deserializer = new DeserializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();

            var yamlObject = deserializer.Deserialize<object>(yamlContent);
            Data = FlattenYaml(yamlObject);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to parse YAML configuration file '{_path}': {ex.Message}", ex);
        }
    }

    private static Dictionary<string, string?> FlattenYaml(object? node, string? prefix = null)
    {
        var result = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);

        if (node is Dictionary<object, object> dict)
        {
            foreach (var kvp in dict)
            {
                var key = kvp.Key?.ToString() ?? string.Empty;
                var fullKey = string.IsNullOrEmpty(prefix) ? key : $"{prefix}:{key}";
                var nested = FlattenYaml(kvp.Value, fullKey);
                foreach (var item in nested)
                {
                    result[item.Key] = item.Value;
                }
            }
        }
        else if (node is IList<object> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                var fullKey = string.IsNullOrEmpty(prefix) ? i.ToString() : $"{prefix}:{i}";
                var nested = FlattenYaml(list[i], fullKey);
                foreach (var item in nested)
                {
                    result[item.Key] = item.Value;
                }
            }
        }
        else
        {
            var key = prefix ?? string.Empty;
            result[key] = node?.ToString();
        }

        return result;
    }
}
