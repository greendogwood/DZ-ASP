using ConfigHomework;
using ConfigHomework.Configuration;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Add custom YAML configuration source
builder.Configuration.AddYamlFile("appsettings.yml", optional: false);

// Register ApplicationOptions with validation
builder.Services.AddOptions<ApplicationOptions>()
    .Bind(builder.Configuration.GetSection(ApplicationOptions.SectionName))
    .Validate(options =>
    {
        if (string.IsNullOrWhiteSpace(options.Name))
            return false;
        if (string.IsNullOrWhiteSpace(options.Version))
            return false;
        if (options.MaxItems <= 0)
            return false;
        return true;
    }, "Application configuration is invalid: Name and Version must not be empty, MaxItems must be greater than 0.")
    .ValidateOnStart();

builder.Services.AddSingleton<ApplicationInfoService>();

var app = builder.Build();

// Root endpoint
app.MapGet("/", () => Results.Redirect("/api/settings"));

// Endpoint 1: /api/settings - demonstrates IConfiguration in two ways
app.MapGet("/api/settings", (IConfiguration configuration) =>
{
    // Way 1: by key
    var nameByKey = configuration["Application:Name"];
    var versionByKey = configuration["Application:Version"];
    var maxItemsByKey = configuration.GetValue<int>("Application:MaxItems");

    // Way 2: by section
    var applicationSection = configuration.GetSection("Application");
    var nameBySection = applicationSection["Name"];
    var versionBySection = applicationSection["Version"];
    var maxItemsBySection = applicationSection.GetValue<int>("MaxItems");

    // Also show Features from YAML
    var featuresSection = configuration.GetSection("Features");

    return Results.Ok(new
    {
        ByKey = new
        {
            Name = nameByKey,
            Version = versionByKey,
            MaxItems = maxItemsByKey
        },
        BySection = new
        {
            Name = nameBySection,
            Version = versionBySection,
            MaxItems = maxItemsBySection
        },
        Features = featuresSection.Get<Dictionary<string, bool>>() ?? new Dictionary<string, bool>(),
        Environment = app.Environment.EnvironmentName
    });
});

// Endpoint 2: /api/application-info - uses the service with IOptionsMonitor
app.MapGet("/api/application-info", (ApplicationInfoService service) =>
{
    return Results.Ok(service.GetApplicationInfo());
});

// Additional endpoint to show difference explanation
app.MapGet("/api/options-info", (IOptions<ApplicationOptions> options,
                                  IOptionsSnapshot<ApplicationOptions> snapshot,
                                  IOptionsMonitor<ApplicationOptions> monitor) =>
{
    return Results.Ok(new
    {
        Explanation = new
        {
            IOptions = "Singleton. Values are cached at startup. Does not react to configuration changes.",
            IOptionsSnapshot = "Scoped. Reloads configuration for each request (in Web apps). Suitable for request-specific values.",
            IOptionsMonitor = "Singleton. Supports change notifications via OnChange. CurrentValue always returns the latest. Best for long-lived services."
        },
        CurrentFromMonitor = monitor.CurrentValue,
        Note = "In this application we use IOptionsMonitor in ApplicationInfoService to support potential hot reload of configuration."
    });
});

app.Run();
