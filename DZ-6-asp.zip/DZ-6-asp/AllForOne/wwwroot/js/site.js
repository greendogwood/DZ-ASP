// JavaScript-файл для демонстрации загрузки скрипта
console.log("JavaScript успешно загружен из /js/site.js");

// Простая анимация или сообщение
document.addEventListener("DOMContentLoaded", function () {
    alert("Статические файлы (CSS, JS, изображения) загружены корректно!");
});
