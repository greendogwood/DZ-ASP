Доступен по /shared/test.txt
