// JS для Public
console.log("JS из Public загружен");
document.addEventListener("DOMContentLoaded", () => {
    console.log("MapStaticAssets работает с кастомным web root");
});
