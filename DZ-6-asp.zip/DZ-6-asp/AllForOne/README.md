# Домашнее задание: Статические файлы ASP.NET Core

Проект для JetBrains Rider (откройте .sln или .csproj).

## Запуск
1. Откройте папку в Rider.
2. Выполните `dotnet run` или F5 (нужен .NET 10 или 9+).
3. Откройте https://localhost:xxxx/ — должен открыться index.html.

## Задание 1
- Файлы в wwwroot: index.html, css/site.css, js/site.js, images/*.jpg
- В Program.cs: UseDefaultFiles() перед UseStaticFiles().
- Проверьте порядок: если поменять местами — index.html не откроется автоматически.

## Задание 2
- Папка Public с аналогичными файлами.
- Чтобы сделать Public web root: раскомментируйте код с WebApplicationOptions в Program.cs и закомментируйте обычный CreateBuilder.
- Используйте MapStaticAssets() (требуется .NET 9+).
- Особенности: MapStaticAssets делает fingerprinting и сжатие на этапе сборки, лучше для известных файлов. UseStaticFiles — middleware, работает с любыми файлами в runtime.

## Задание 3
- Папка SharedFiles (или создайте свою вне проекта).
- Настроена через PhysicalFileProvider с префиксом /shared.
- Проверьте /shared/test.txt. Несуществующие файлы → 404. Файлы не доступны вне /shared.

Все строки в Program.cs прокомментированы.
