using Microsoft.Extensions.FileProviders;

// Создаём билдер приложения ASP.NET Core
var builder = WebApplication.CreateBuilder(args);

// === Задание 2: Изменение web root на папку Public (раскомментируйте для проверки) ===
// var builder = WebApplication.CreateBuilder(new WebApplicationOptions
// {
//     Args = args,
//     WebRootPath = "Public" // Устанавливаем папку Public как web root вместо wwwroot
// });

// Собираем приложение
var app = builder.Build();

// Включаем перенаправление на HTTPS
app.UseHttpsRedirection();

// Задание 1: Раздача статических файлов и файл по умолчанию

// UseDefaultFiles должен идти ПЕРЕД UseStaticFiles.
// Он переписывает URL (например, / становится /index.html), но сам файл не отдаёт.
app.UseDefaultFiles(); // Раскомментируйте и поставьте после UseStaticFiles, чтобы увидеть разницу (index.html не откроется автоматически)

// UseStaticFiles отдаёт файлы из web root (по умолчанию wwwroot)
app.UseStaticFiles();

// Если поменять порядок (сначала UseStaticFiles, потом UseDefaultFiles) — default file не сработает,
// потому что UseDefaultFiles — это URL rewriter, а UseStaticFiles уже обработал запрос к корню как 404.

// Задание 2: MapStaticAssets
// MapStaticAssets использует endpoint routing, fingerprinting, сжатие на этапе сборки.
// Лучше всего для файлов, известных на этапе build/publish.
// Не заменяет полностью UseDefaultFiles + UseStaticFiles для default documents.
app.MapStaticAssets();

// Задание 3: Раздача файлов из внешней папки через PhysicalFileProvider
// Создайте папку вне проекта, например C:\SharedFiles или /tmp/SharedFiles, и положите туда файлы.
// Здесь пример для папки SharedFiles рядом с проектом (для удобства теста).
var sharedPath = Path.Combine(builder.Environment.ContentRootPath, "SharedFiles");
if (Directory.Exists(sharedPath))
{
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = new PhysicalFileProvider(sharedPath), // Физический провайдер файлов
        RequestPath = "/shared" // URL-префикс: файлы доступны по /shared/filename
    });
}

// Пример эндпоинта для проверки
app.MapGet("/test", () => "Приложение работает. Проверьте / (index.html), /css/site.css, /shared/...");

// Запускаем приложение
app.Run();
// http://localhost:5000