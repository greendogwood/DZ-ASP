# Домашнее задание: ASP.NET Core Middleware

## Запуск

```bash
cd AspNetMiddlewareHomework
dotnet run
```

Приложение запустится на `http://localhost:5000` (или другой порт, указанный в консоли).

## Проверка

### Задача 1. Терминальный обработчик Run
В `Program.cs` раскомментируйте первый блок и закомментируйте остальное.  
Примеры запросов:
- `http://localhost:5000/`
- `http://localhost:5000/api/test?param=1`

### Задача 2. Use
По умолчанию включена. Смотрите консоль при запросах — увидите порядок выполнения (до `next` и после).

### Задача 3. UseMiddleware + KeyCheckMiddleware
- Без параметра: `http://localhost:5000/` → 400 Bad Request
- С параметром: `http://localhost:5000/?key=secret123` → успешный ответ + заголовок `X-Processed-By`

## Структура
- `Program.cs` — настройка конвейера
- `Middleware/KeyCheckMiddleware.cs` — собственный middleware
