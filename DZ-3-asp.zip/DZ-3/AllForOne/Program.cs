var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// 1. Терминальный обработчик Run
// Раскомментируйте этот блок и закомментируйте остальные,
// чтобы проверить только терминальный Run.

/*
app.Run(async context =>
{
    var url = $"{context.Request.Path}{context.Request.QueryString}";
    var method = context.Request.Method;
    var time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

    var message = $"URL: {url}\nHTTP-метод: {method}\nВремя сервера: {time}";
    await context.Response.WriteAsync(message);
});

// Этот код НЕ будет выполняться при обработке запросов,
// Потому что Run — терминальный middleware.
Console.WriteLine("Этот код после Run никогда не вызовется для запросов!");

app.Run();
return;
*/

// 2. Обработка запросов с помощью Use

app.Use(async (context, next) =>
{
    Console.WriteLine($"[Middleware 1] Начало обработки запроса: {context.Request.Method} {context.Request.Path}");
    await next();
    Console.WriteLine("[Middleware 1] После вызова next()");
});

app.Use(async (context, next) =>
{
    context.Response.Headers["X-Processed-By"] = "SecondMiddlewareComponent";
    Console.WriteLine("[Middleware 2] Добавлен заголовок X-Processed-By");
    await next();
    Console.WriteLine("[Middleware 2] После вызова next()");
});

// 3. Собственный middleware через UseMiddleware

app.UseMiddleware<MiddlewareDemo.Middleware.KeyCheckMiddleware>();

// Терминальный обработчик (формирует текстовый ответ)
app.Run(async context =>
{
    context.Response.ContentType = "text/plain; charset=utf-8";
    var key = context.Request.Query["key"];
    var message = $"Запрос успешно обработан!\n" +
                  $"Полученный key: {key}\n" +
                  $"Время: {DateTime.Now:HH:mm:ss}";
    await context.Response.WriteAsync(message);
});

app.Run();
