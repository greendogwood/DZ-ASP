using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace MiddlewareDemo.Middleware
{

    public class KeyCheckMiddleware
    {
        private readonly RequestDelegate _next;

        public KeyCheckMiddleware(RequestDelegate next)
        {
            _next = next;

        }

        public async Task InvokeAsync(HttpContext context)
        {
            var key = context.Request.Query["key"].ToString();

            if (string.IsNullOrWhiteSpace(key))
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                context.Response.ContentType = "text/plain; charset=utf-8";
                await context.Response.WriteAsync("Ошибка: параметр 'key' отсутствует или пуст. Укажите ?key=значение в запросе.");
                return;
            }
            await _next(context);
        }
    }
}
