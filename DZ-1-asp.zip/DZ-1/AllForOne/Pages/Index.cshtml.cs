using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET_Homework_AllInOne.Pages;

public class IndexModel : PageModel
{
    public int DayOfYear { get; private set; }
    public char RandomLetter { get; private set; }

    public void OnGet()
    {
        DayOfYear = DateTime.Now.DayOfYear;

        var random = new Random();
        RandomLetter = (char)('A' + random.Next(0, 26));
    }
}
