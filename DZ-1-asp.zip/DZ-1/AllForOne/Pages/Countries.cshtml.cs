using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET_Homework_AllInOne.Pages;

public class CountriesModel : PageModel
{
    public List<Country> Countries { get; private set; } = new();

    public void OnGet()
    {
        Countries = new List<Country>
        {
            new() { Name = "Россия", Capital = "Москва", Population = "146 млн" },
            new() { Name = "Франция", Capital = "Париж", Population = "67 млн" },
            new() { Name = "Япония", Capital = "Токио", Population = "125 млн" },
            new() { Name = "Бразилия", Capital = "Бразилиа", Population = "215 млн" },
            new() { Name = "Канада", Capital = "Оттава", Population = "38 млн" }
        };
    }
}

public class Country
{
    public string Name { get; set; } = "";
    public string Capital { get; set; } = "";
    public string Population { get; set; } = "";
}
