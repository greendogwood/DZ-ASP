using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET_Homework_AllInOne.Pages;

public class RestaurantsModel : PageModel
{
    public char RandomLetter { get; private set; }
    public List<Restaurant> Restaurants { get; private set; } = new();

    public void OnGet()
    {
        var random = new Random();
        RandomLetter = (char)('A' + random.Next(0, 26));

        Restaurants = new List<Restaurant>
        {
            new() { Name = "La Bella Italia", Cuisine = "Итальянская", Rating = 4.7 },
            new() { Name = "Sushi Master", Cuisine = "Японская", Rating = 4.5 },
            new() { Name = "Борщ & Котлета", Cuisine = "Русская", Rating = 4.9 },
            new() { Name = "Paris Bistro", Cuisine = "Французская", Rating = 4.8 },
            new() { Name = "Taco Loco", Cuisine = "Мексиканская", Rating = 1.2 }
        };
    }
}

public class Restaurant
{
    public string Name { get; set; } = "";
    public string Cuisine { get; set; } = "";
    public double Rating { get; set; }
}
