using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET_Homework_AllInOne.Pages;

public class RestaurantModel : PageModel
{
    public string Name { get; set; } = "La Bella Italia";
    public string Cuisine { get; set; } = "Итальянская";
    public string Address { get; set; } = "ул. Центральная, 15";
    public double Rating { get; set; } = 4.7;
    public string Description { get; set; } = "Уютный ресторан с аутентичной итальянской кухней, свежей пастой и отличным вином.";

    public void OnGet()
    {
    }
}
