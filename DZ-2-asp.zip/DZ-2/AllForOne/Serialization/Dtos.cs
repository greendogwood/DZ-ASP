namespace IoCHomework.Serialization;

public class AnimalDto
{
    public string Type { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public class FigureDto
{
    public string Type { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}