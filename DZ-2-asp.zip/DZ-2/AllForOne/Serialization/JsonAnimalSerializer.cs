using System.Text.Json;
using IoCHomework.Animals;
using IoCHomework.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace IoCHomework.Serialization;

public interface IAnimalSerializer
{
    void Save(IEnumerable<Animal> animals, string filePath);
    List<Animal> Load(string filePath, IServiceProvider serviceProvider);
}

public class JsonAnimalSerializer : IAnimalSerializer
{
    public void Save(IEnumerable<Animal> animals, string filePath)
    {
        var dtos = animals.Select(a => new AnimalDto
        {
            Type = a.GetType().Name,
            Name = a.Name
        }).ToList();

        var options = new JsonSerializerOptions { WriteIndented = true };
        var json = JsonSerializer.Serialize(dtos, options);
        File.WriteAllText(filePath, json);
    }

    public List<Animal> Load(string filePath, IServiceProvider serviceProvider)
    {
        if (!File.Exists(filePath))
            return new List<Animal>();

        var json = File.ReadAllText(filePath);
        var dtos = JsonSerializer.Deserialize<List<AnimalDto>>(json) ?? new List<AnimalDto>();

        var animals = new List<Animal>();
        foreach (var dto in dtos)
        {
            // Resolve with default outputs or specific. For demo, use console for both
            var nameOutput = serviceProvider.GetRequiredService<IOutput>(); // or named
            var soundOutput = serviceProvider.GetRequiredService<IOutput>();

            Animal? animal = dto.Type switch
            {
                "Dog" => ActivatorUtilities.CreateInstance<Dog>(serviceProvider, nameOutput, soundOutput),
                "Cat" => ActivatorUtilities.CreateInstance<Cat>(serviceProvider, nameOutput, soundOutput),
                "Cow" => ActivatorUtilities.CreateInstance<Cow>(serviceProvider, nameOutput, soundOutput),
                _ => null
            };

            if (animal != null)
            {
                animal.Name = dto.Name;
                animals.Add(animal);
            }
        }

        return animals;
    }
}