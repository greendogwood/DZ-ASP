using System.Text.Json;
using IoCHomework.Figures;
using IoCHomework.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace IoCHomework.Serialization;

public interface IFigureSerializer
{
    void Save(IEnumerable<Figure> figures, string filePath);
    List<Figure> Load(string filePath, IServiceProvider serviceProvider);
}

public class JsonFigureSerializer : IFigureSerializer
{
    public void Save(IEnumerable<Figure> figures, string filePath)
    {
        var dtos = figures.Select(f => new FigureDto
        {
            Type = f.GetType().Name,
            Name = f.Name
        }).ToList();

        var options = new JsonSerializerOptions { WriteIndented = true };
        var json = JsonSerializer.Serialize(dtos, options);
        File.WriteAllText(filePath, json);
    }

    public List<Figure> Load(string filePath, IServiceProvider serviceProvider)
    {
        if (!File.Exists(filePath))
            return new List<Figure>();

        var json = File.ReadAllText(filePath);
        var dtos = JsonSerializer.Deserialize<List<FigureDto>>(json) ?? new List<FigureDto>();

        var figures = new List<Figure>();
        foreach (var dto in dtos)
        {
            var nameOutput = serviceProvider.GetRequiredService<IOutput>();
            var visualOutput = serviceProvider.GetRequiredService<IOutput>();

            Figure? figure = dto.Type switch
            {
                "Circle" => ActivatorUtilities.CreateInstance<Circle>(serviceProvider, nameOutput, visualOutput),
                "Square" => ActivatorUtilities.CreateInstance<Square>(serviceProvider, nameOutput, visualOutput),
                "Triangle" => ActivatorUtilities.CreateInstance<Triangle>(serviceProvider, nameOutput, visualOutput),
                _ => null
            };

            if (figure != null)
            {
                figure.Name = dto.Name;
                figures.Add(figure);
            }
        }

        return figures;
    }
}