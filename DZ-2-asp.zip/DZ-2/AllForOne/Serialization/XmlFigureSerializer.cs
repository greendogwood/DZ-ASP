using System.Xml.Serialization;
using IoCHomework.Figures;
using IoCHomework.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace IoCHomework.Serialization;

public class XmlFigureSerializer : IFigureSerializer
{
    public void Save(IEnumerable<Figure> figures, string filePath)
    {
        var dtos = figures.Select(f => new FigureDto
        {
            Type = f.GetType().Name,
            Name = f.Name
        }).ToList();

        var serializer = new XmlSerializer(typeof(List<FigureDto>));
        using var stream = new FileStream(filePath, FileMode.Create);
        serializer.Serialize(stream, dtos);
    }

    public List<Figure> Load(string filePath, IServiceProvider serviceProvider)
    {
        if (!File.Exists(filePath))
            return new List<Figure>();

        var serializer = new XmlSerializer(typeof(List<FigureDto>));
        using var stream = new FileStream(filePath, FileMode.Open);
        var dtos = (List<FigureDto>?)serializer.Deserialize(stream) ?? new List<FigureDto>();

        var figures = new List<Figure>();
        foreach (var dto in dtos)
        {
            var nameOutput = serviceProvider.GetRequiredService<IOutput>();
            var visualOutput = serviceProvider.GetRequiredService<IOutput>();

            Figure? figure = dto.Type switch
            {
                "Circle" => ActivatorUtilities.CreateInstance<Circle>(serviceProvider, nameOutput, visualOutput),
                "Square" => ActivatorUtilities.CreateInstance<Square>(serviceProvider, nameOutput, visualOutput),
                "Triangle" => ActivatorUtilities.CreateInstance<Triangle>(serviceProvider, nameOutput, visualOutput),
                _ => null
            };

            if (figure != null)
            {
                figure.Name = dto.Name;
                figures.Add(figure);
            }
        }

        return figures;
    }
}