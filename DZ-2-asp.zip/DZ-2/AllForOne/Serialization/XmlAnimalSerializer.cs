using System.Xml.Serialization;
using IoCHomework.Animals;
using IoCHomework.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace IoCHomework.Serialization;

public class XmlAnimalSerializer : IAnimalSerializer
{
    public void Save(IEnumerable<Animal> animals, string filePath)
    {
        var dtos = animals.Select(a => new AnimalDto
        {
            Type = a.GetType().Name,
            Name = a.Name
        }).ToList();

        var serializer = new XmlSerializer(typeof(List<AnimalDto>));
        using var stream = new FileStream(filePath, FileMode.Create);
        serializer.Serialize(stream, dtos);
    }

    public List<Animal> Load(string filePath, IServiceProvider serviceProvider)
    {
        if (!File.Exists(filePath))
            return new List<Animal>();

        var serializer = new XmlSerializer(typeof(List<AnimalDto>));
        using var stream = new FileStream(filePath, FileMode.Open);
        var dtos = (List<AnimalDto>?)serializer.Deserialize(stream) ?? new List<AnimalDto>();

        var animals = new List<Animal>();
        foreach (var dto in dtos)
        {
            var nameOutput = serviceProvider.GetRequiredService<IOutput>();
            var soundOutput = serviceProvider.GetRequiredService<IOutput>();

            Animal? animal = dto.Type switch
            {
                "Dog" => ActivatorUtilities.CreateInstance<Dog>(serviceProvider, nameOutput, soundOutput),
                "Cat" => ActivatorUtilities.CreateInstance<Cat>(serviceProvider, nameOutput, soundOutput),
                "Cow" => ActivatorUtilities.CreateInstance<Cow>(serviceProvider, nameOutput, soundOutput),
                _ => null
            };

            if (animal != null)
            {
                animal.Name = dto.Name;
                animals.Add(animal);
            }
        }

        return animals;
    }
}