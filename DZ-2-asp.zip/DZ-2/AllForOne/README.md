# Домашнее задание: IoC и Dependency Injection (ASP.NET Core Module 2)

Проект демонстрирует принципы Inversion of Control и Dependency Injection на примере иерархии животных и геометрических фигур.

## Структура

- **Abstractions/IOutput.cs** — интерфейс для вывода (экран или файл)
- **Outputs/** — реализации: ConsoleOutput, FileOutput
- **Animals/** — иерархия Animal, Dog, Cat, Cow
- **Figures/** — иерархия Figure, Circle, Square, Triangle (с ASCII-визуализацией)
- **Serialization/** — сериализаторы JSON и XML для животных и фигур (через DTO)
- **Program.cs** — демонстрация всех заданий

## Как запустить

```bash
dotnet run
```

Проект использует Microsoft.Extensions.DependencyInjection.

## Что демонстрируется

1. **Задание 1**: Животные с внедрением зависимостей для вывода названия и звука (независимо на экран или в файл).
2. **Задание 2**: Сохранение/загрузка массива животных в JSON и XML.
3. **Задание 3**: Аналогично для фигур + визуальное отображение.
4. **Задание 4**: Сохранение/загрузка массива фигур в разных форматах.

Все зависимости внедряются через конструкторы (Constructor Injection), используется DI-контейнер.