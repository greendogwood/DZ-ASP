namespace IoCHomework.Abstractions;

public interface IOutput
{
    void Write(string message);
}