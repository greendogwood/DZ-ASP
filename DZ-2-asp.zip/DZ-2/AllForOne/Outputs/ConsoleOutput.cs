using IoCHomework.Abstractions;

namespace IoCHomework.Outputs;

public class ConsoleOutput : IOutput
{
    public void Write(string message)
    {
        Console.WriteLine(message);
    }
}