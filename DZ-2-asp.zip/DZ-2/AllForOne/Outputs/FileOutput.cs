using IoCHomework.Abstractions;

namespace IoCHomework.Outputs;

public class FileOutput : IOutput
{
    private readonly string _filePath;

    public FileOutput(string filePath)
    {
        _filePath = filePath;
        // Ensure file exists or create empty
        if (!File.Exists(_filePath))
        {
            File.WriteAllText(_filePath, string.Empty);
        }
    }

    public void Write(string message)
    {
        File.AppendAllText(_filePath, message + Environment.NewLine);
    }
}