using IoCHomework.Abstractions;
using IoCHomework.Animals;
using IoCHomework.Figures;
using IoCHomework.Outputs;
using IoCHomework.Serialization;
using Microsoft.Extensions.DependencyInjection;

namespace IoCHomework;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("=== Домашнее задание: IoC и Dependency Injection ===\n");

        // Настройка DI контейнера
        var services = new ServiceCollection();

        // Регистрируем выводы
        services.AddSingleton<IOutput, ConsoleOutput>(); // по умолчанию консоль
        services.AddTransient<JsonAnimalSerializer>();
        services.AddTransient<XmlAnimalSerializer>();
        services.AddTransient<JsonFigureSerializer>();
        services.AddTransient<XmlFigureSerializer>();

        // Можно регистрировать конкретные сериализаторы по интерфейсу с ключами, но для простоты используем конкретные типы
        var serviceProvider = services.BuildServiceProvider();

        // === Задание 1 и 2: Животные ===
        Console.WriteLine("--- Задание 1: Иерархия животных с IoC/DI ---");

        var consoleOutput = new ConsoleOutput();
        var fileOutputName = new FileOutput("animal_names.txt");
        var fileOutputSound = new FileOutput("animal_sounds.txt");

        // Создаём животных с разными выводами (Dependency Injection через конструктор)
        var dog = new Dog(consoleOutput, consoleOutput) { Name = "Бобик" };
        var cat = new Cat(fileOutputName, consoleOutput) { Name = "Мурка" };
        var cow = new Cow(consoleOutput, fileOutputSound) { Name = "Бурёнка" };

        var animals = new List<Animal> { dog, cat, cow };

        Console.WriteLine("\nОтображение животных:");
        foreach (var animal in animals)
        {
            animal.DisplayName();
            animal.DisplaySound();
            Console.WriteLine();
        }

        Console.WriteLine("Проверьте файлы animal_names.txt и animal_sounds.txt для вывода в файл.\n");

        // === Задание 2: Сохранение/загрузка в разных форматах ===
        Console.WriteLine("--- Задание 2: Сериализация животных (JSON и XML) ---");

        var jsonSerializer = serviceProvider.GetRequiredService<JsonAnimalSerializer>();
        var xmlSerializer = serviceProvider.GetRequiredService<XmlAnimalSerializer>();

        string jsonPath = "animals.json";
        string xmlPath = "animals.xml";

        jsonSerializer.Save(animals, jsonPath);
        xmlSerializer.Save(animals, xmlPath);

        Console.WriteLine($"Сохранено в {jsonPath} и {xmlPath}");

        // Загрузка (используем DI для создания экземпляров)
        var loadedFromJson = jsonSerializer.Load(jsonPath, serviceProvider);
        Console.WriteLine("\nЗагружено из JSON:");
        foreach (var a in loadedFromJson)
        {
            Console.WriteLine(a);
            a.DisplayName();
            a.DisplaySound();
        }

        var loadedFromXml = xmlSerializer.Load(xmlPath, serviceProvider);
        Console.WriteLine("\nЗагружено из XML:");
        foreach (var a in loadedFromXml)
        {
            Console.WriteLine(a);
            a.DisplayName();
            a.DisplaySound();
        }

        // === Задание 3 и 4: Фигуры ===
        Console.WriteLine("\n--- Задание 3: Иерархия геометрических фигур с IoC/DI ---");

        var fileOutputVisual = new FileOutput("figure_visuals.txt");

        var circle = new Circle(consoleOutput, consoleOutput) { Name = "Круг" };
        var square = new Square(consoleOutput, fileOutputVisual) { Name = "Квадрат" };
        var triangle = new Triangle(fileOutputName, consoleOutput) { Name = "Треугольник" }; // name to file

        var figures = new List<Figure> { circle, square, triangle };

        Console.WriteLine("\nОтображение фигур:");
        foreach (var figure in figures)
        {
            figure.DisplayName();
            figure.DisplayVisual();
            Console.WriteLine();
        }

        Console.WriteLine("Проверьте файл figure_visuals.txt для визуального вывода в файл.\n");

        // === Задание 4: Сериализация фигур ===
        Console.WriteLine("--- Задание 4: Сериализация фигур (JSON и XML) ---");

        var jsonFigSerializer = serviceProvider.GetRequiredService<JsonFigureSerializer>();
        var xmlFigSerializer = serviceProvider.GetRequiredService<XmlFigureSerializer>();

        string figJsonPath = "figures.json";
        string figXmlPath = "figures.xml";

        jsonFigSerializer.Save(figures, figJsonPath);
        xmlFigSerializer.Save(figures, figXmlPath);

        Console.WriteLine($"Сохранено в {figJsonPath} и {figXmlPath}");

        var loadedFigsJson = jsonFigSerializer.Load(figJsonPath, serviceProvider);
        Console.WriteLine("\nЗагружено из JSON:");
        foreach (var f in loadedFigsJson)
        {
            Console.WriteLine(f);
            f.DisplayName();
            f.DisplayVisual();
        }

        Console.WriteLine("\n=== Готово! Все задания выполнены в одном проекте с использованием IoC и DI. ===");
    }
}