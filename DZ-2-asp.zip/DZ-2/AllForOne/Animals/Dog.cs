using IoCHomework.Abstractions;

namespace IoCHomework.Animals;

public class Dog : Animal
{
    public override string Sound => "Гав-гав!";

    public Dog(IOutput nameOutput, IOutput soundOutput) : base(nameOutput, soundOutput)
    {
    }
}