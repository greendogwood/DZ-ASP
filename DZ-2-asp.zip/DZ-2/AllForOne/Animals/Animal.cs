using IoCHomework.Abstractions;

namespace IoCHomework.Animals;

public abstract class Animal
{
    public string Name { get; set; } = string.Empty;

    public abstract string Sound { get; }

    protected readonly IOutput NameOutput;
    protected readonly IOutput SoundOutput;

    protected Animal(IOutput nameOutput, IOutput soundOutput)
    {
        NameOutput = nameOutput;
        SoundOutput = soundOutput;
    }

    public void DisplayName()
    {
        NameOutput.Write($"Название животного: {Name}");
    }

    public void DisplaySound()
    {
        SoundOutput.Write($"Звук: {Sound}");
    }

    public override string ToString() => $"{GetType().Name}: {Name}";
}