using IoCHomework.Abstractions;

namespace IoCHomework.Animals;

public class Cat : Animal
{
    public override string Sound => "Мяу!";

    public Cat(IOutput nameOutput, IOutput soundOutput) : base(nameOutput, soundOutput)
    {
    }
}