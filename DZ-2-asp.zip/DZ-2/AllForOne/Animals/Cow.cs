using IoCHomework.Abstractions;

namespace IoCHomework.Animals;

public class Cow : Animal
{
    public override string Sound => "Муу!";

    public Cow(IOutput nameOutput, IOutput soundOutput) : base(nameOutput, soundOutput)
    {
    }
}