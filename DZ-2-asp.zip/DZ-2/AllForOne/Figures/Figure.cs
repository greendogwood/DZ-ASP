using IoCHomework.Abstractions;

namespace IoCHomework.Figures;

public abstract class Figure
{
    public string Name { get; set; } = string.Empty;

    public abstract string Visual { get; }

    protected readonly IOutput NameOutput;
    protected readonly IOutput VisualOutput;

    protected Figure(IOutput nameOutput, IOutput visualOutput)
    {
        NameOutput = nameOutput;
        VisualOutput = visualOutput;
    }

    public void DisplayName()
    {
        NameOutput.Write($"Название фигуры: {Name}");
    }

    public void DisplayVisual()
    {
        VisualOutput.Write($"Визуальное отображение:\n{Visual}");
    }

    public override string ToString() => $"{GetType().Name}: {Name}";
}