using IoCHomework.Abstractions;

namespace IoCHomework.Figures;

public class Circle : Figure
{
    public override string Visual => """
          ****
       **      **
     *            *
    *              *
     *            *
       **      **
          ****
    """;

    public Circle(IOutput nameOutput, IOutput visualOutput) : base(nameOutput, visualOutput)
    {
    }
}