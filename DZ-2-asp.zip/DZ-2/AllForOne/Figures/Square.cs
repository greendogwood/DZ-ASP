using IoCHomework.Abstractions;

namespace IoCHomework.Figures;

public class Square : Figure
{
    public override string Visual => """
    ********
    *      *
    *      *
    *      *
    ********
    """;

    public Square(IOutput nameOutput, IOutput visualOutput) : base(nameOutput, visualOutput)
    {
    }
}