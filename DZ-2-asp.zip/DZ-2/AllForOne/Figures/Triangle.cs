using IoCHomework.Abstractions;

namespace IoCHomework.Figures;

public class Triangle : Figure
{
    public override string Visual => """
        *
       * *
      *   *
     *     *
    *********
    """;

    public Triangle(IOutput nameOutput, IOutput visualOutput) : base(nameOutput, visualOutput)
    {
    }
}