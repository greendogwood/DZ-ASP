using System.Text;
var builder = WebApplication.CreateBuilder(args);

//Часть 2: DI и времена жизни
builder.Services.AddSingleton<SingletonService>();
builder.Services.AddScoped<ScopedService>();
builder.Services.AddTransient<TransientService>();

//Часть 3: две реализации IReportService
builder.Services.AddTransient<IReportService, PdfReportService>();
builder.Services.AddTransient<IReportService, CsvReportService>();

var app = builder.Build();

// Часть 1: UseWhen / MapWhen

// UseWhen: ветка ВОЗВРАЩАЕТСЯ в основной конвейер (next вызывается дальше).
app.UseWhen(
    ctx => ctx.Request.Path.StartsWithSegments("/api"),
    branch =>
    {
        branch.Use(async (ctx, next) =>
        {
            ctx.Response.Headers["X-Branch"] = "UseWhen";
            await next();
        });
    });

// MapWhen: ветка ТЕРМИНАЛЬНАЯ - в основной конвейер не возвращается.
app.MapWhen(
    ctx => ctx.Request.Query["debug"] == "true",
    branch =>
    {
        branch.Run(ctx => WriteText(ctx, "Debug-ответ из ветки MapWhen (debug=true)"));
    });

// Часть 2: middleware с DI
app.UseMiddleware<DiMiddleware>();

// Показывает id всех трёх сервисов
app.Map("/di", branch => branch.Run(async ctx =>
{
    var sb = new StringBuilder();
    sb.AppendLine("== Из middleware (внедрено через конструктор / InvokeAsync) ==");
    sb.AppendLine($"Singleton: {ctx.Items["mw-singleton"]}");
    sb.AppendLine($"Scoped:    {ctx.Items["mw-scoped"]}");
    sb.AppendLine($"Transient: {ctx.Items["mw-transient"]}");
    sb.AppendLine();
    sb.AppendLine("== Из HttpContext.RequestServices (в обработчике маршрута) ==");
    sb.AppendLine($"Singleton: {ctx.RequestServices.GetRequiredService<SingletonService>().Id}");
    sb.AppendLine($"Scoped:    {ctx.RequestServices.GetRequiredService<ScopedService>().Id}");
    sb.AppendLine($"Transient: {ctx.RequestServices.GetRequiredService<TransientService>().Id}");
    sb.AppendLine();
    sb.AppendLine("Singleton и Scoped совпадают внутри запроса, Transient - всегда новый.");
    await WriteText(ctx, sb.ToString());
}));

// Отдельный маршрут: как меняется Scoped между запросами
app.Map("/scoped", branch => branch.Run(async ctx =>
{
    var first = ctx.RequestServices.GetRequiredService<ScopedService>().Id;
    var second = ctx.RequestServices.GetRequiredService<ScopedService>().Id;
    var singleton = ctx.RequestServices.GetRequiredService<SingletonService>().Id;

    await WriteText(ctx,
        $"Scoped (1-й вызов в запросе): {first}\n" +
        $"Scoped (2-й вызов в запросе): {second}\n" +
        $"Одинаковы внутри запроса: {first == second}\n" +
        $"Singleton для сравнения:     {singleton}\n\n" +
        "Обновите страницу: Scoped изменится, Singleton останется прежним.");
}));

// Часть 3: IServiceProvider

// Маршрут 1: сервис через HttpContext.RequestServices
app.Map("/report/rs", branch => branch.Run(async ctx =>
{
    var type = ctx.Request.Query["type"].ToString();
    var service = ctx.RequestServices
        .GetServices<IReportService>()
        .FirstOrDefault(s => s.Name.Equals(type, StringComparison.OrdinalIgnoreCase));

    if (service is null)
    {
        ctx.Response.StatusCode = 400;
        await WriteText(ctx, "Укажите ?type=pdf или ?type=csv");
        return;
    }

    await WriteText(ctx,
        "Способ получения: HttpContext.RequestServices\n" +
        $"Реализация: {service.GetType().Name}\n" +
        $"Результат: {service.Generate()}");
}));

// Маршрут 2: сервис через внедрённый в middleware IServiceProvider
app.Map("/report/sp", branch => branch.UseMiddleware<ReportByProviderMiddleware>());

// Сравнение Scoped-сервиса: текущий запрос vs отдельный scope (CreateScope)
app.Map("/scope-compare", branch => branch.Run(async ctx =>
{
    var requestScoped = ctx.RequestServices.GetRequiredService<ScopedService>();

    using var scope = ctx.RequestServices.CreateScope();
    var otherScoped = scope.ServiceProvider.GetRequiredService<ScopedService>();

    await WriteText(ctx,
        $"Scoped из контекста запроса: {requestScoped.Id}\n" +
        $"Scoped из CreateScope():     {otherScoped.Id}\n" +
        $"Один и тот же экземпляр: {ReferenceEquals(requestScoped, otherScoped)}\n\n" +
        "Каждый scope имеет свой экземпляр Scoped-сервиса.");
}));

// Основная ветка: для всех остальных запросов
app.Run(ctx => WriteText(ctx, "Ответ основной ветки конвейера"));

app.Run();

static Task WriteText(HttpContext ctx, string text)
{
    ctx.Response.ContentType = "text/plain; charset=utf-8";
    return ctx.Response.WriteAsync(text);
}

// Сервисы и middleware

public class SingletonService { public Guid Id { get; } = Guid.NewGuid(); }
public class ScopedService { public Guid Id { get; } = Guid.NewGuid(); }
public class TransientService { public Guid Id { get; } = Guid.NewGuid(); }

// Singleton - через конструктор; Scoped и Transient - через InvokeAsync
// (Scoped нельзя внедрять в конструктор middleware: оно создаётся один раз).
public class DiMiddleware
{
    private readonly RequestDelegate _next;
    private readonly SingletonService _singleton;

    public DiMiddleware(RequestDelegate next, SingletonService singleton)
    {
        _next = next;
        _singleton = singleton;
    }

    public async Task InvokeAsync(HttpContext ctx, ScopedService scoped, TransientService transient)
    {
        ctx.Items["mw-singleton"] = _singleton.Id;
        ctx.Items["mw-scoped"] = scoped.Id;
        ctx.Items["mw-transient"] = transient.Id;
        await _next(ctx);
    }
}

public interface IReportService
{
    string Name { get; }
    string Generate();
}

public class PdfReportService : IReportService
{
    public string Name => "pdf";
    public string Generate() => "PDF-отчёт сформирован (3 страницы)";
}

public class CsvReportService : IReportService
{
    public string Name => "csv";
    public string Generate() => "id;name;total\n1;Alice;100\n2;Bob;250";
}

// IServiceProvider, внедрённый в InvokeAsync, - это провайдер текущего запроса.
public class ReportByProviderMiddleware
{
    private readonly RequestDelegate _next;

    public ReportByProviderMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext ctx, IServiceProvider sp)
    {
        var type = ctx.Request.Query["type"].ToString();
        var service = sp.GetServices<IReportService>()
            .FirstOrDefault(s => s.Name.Equals(type, StringComparison.OrdinalIgnoreCase));

        ctx.Response.ContentType = "text/plain; charset=utf-8";

        if (service is null)
        {
            ctx.Response.StatusCode = 400;
            await ctx.Response.WriteAsync("Укажите ?type=pdf или ?type=csv");
            return;
        }

        await ctx.Response.WriteAsync(
            "Способ получения: внедрённый IServiceProvider\n" +
            $"Реализация: {service.GetType().Name}\n" +
            $"Результат: {service.Generate()}");
    }
}

// localhost:5091/?debug=true показывает debug-текст из MapWhen.
// localhost:5091/api/test покажет ответ основной ветки, а заголовок X-Branch: UseWhen виден только в F12 → Network.
// localhost:5091/api/test?debug=true покажет debug-текст, и заголовок X-Branch тоже будет (это «обе ветки»).
// localhost:5091/di покажет id сервисов. Обнови страницу 2-3 раза: у Scoped и Transient id будут меняться, а у Singleton нет.
// localhost:5091/scoped показывает, как Scoped меняется между запросами.
// localhost:5091/report/rs?type=pdf и localhost:5091/report/sp?type=csv вернут название реализации и результат.
// localhost:5091/scope-compare покажет два разных Scoped id.